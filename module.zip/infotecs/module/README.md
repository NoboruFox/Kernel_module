# simple linux device driver

type 'make help' for help
